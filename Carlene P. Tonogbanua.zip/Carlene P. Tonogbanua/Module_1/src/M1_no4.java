/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class M1_no4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       String ngalan = "Caca";
      char pt = ngalan.charAt(2);
          String pc =" ";
      String c = pc+pt;
        System.out.println("the giving String is: "+ngalan);
      System.out.println("the String contsining at last: "+ngalan.contains(c));    
    }  
    }
    

