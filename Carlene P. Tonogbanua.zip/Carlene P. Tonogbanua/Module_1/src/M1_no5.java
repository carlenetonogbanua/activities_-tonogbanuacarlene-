/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class M1_no5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String buding ="the quick brown fox";
        String ca ="queen";
  System.out.println("the given string is: "+buding);
  System.out.println("the given mask string is: "+ca+"\n");
  
 System.out.println("the new string is: "+buding.replace("e","").replace("n", "").replace("qu", ""));
            
       
    }
    
}
