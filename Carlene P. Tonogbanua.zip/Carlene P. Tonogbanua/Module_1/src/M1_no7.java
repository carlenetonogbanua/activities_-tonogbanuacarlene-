
import java.io.File;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class M1_no7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
       
      
      File myfiles = new File("C:\\Users\\hp\\Documents\\GitHub");
      if (myfiles.exists()) {
    
     String contents[] = myfiles.list();
      System.out.println("List of file/directory is: ");
      for(int i=0; i<contents.length; i++) 
         System.out.println(contents[i]);
        }else{
          System.out.println("file does not exist.\n");
      }
    }
    
}
