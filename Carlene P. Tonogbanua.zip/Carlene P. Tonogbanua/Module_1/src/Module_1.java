/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author User
 */
public class Module_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aa[] = {11, 20, 60,10,99}; 
        int gg[] = new int[aa.length];
        gg=aa;
        System.out.println(" array a[] is:  "); 
        for (int i=0; i<aa.length; i++) 
        System.out.print(aa[i]+" "); 
        System.out.println("\n\n array b[] is: "); 
        for (int i=0; i<gg.length; i++) 
        System.out.print(gg[i] + " "); 
    } 
    }
    
    
    

